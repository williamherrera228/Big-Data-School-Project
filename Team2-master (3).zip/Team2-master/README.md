# Team2
Big Data Analysis Course Project - Nikhil Reddy, John Martinez, William Herrera

Datasets:Complaints 311 (2009-2016) Download:

(2010-2016) https://data.cityofnewyork.us/Social-Services/311/wpe2-h2i5

(2009)      https://data.cityofnewyork.us/Social-Services/new-311/9s88-aed8

  
  
